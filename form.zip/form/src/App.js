import logo from './logo.svg';
import './App.css';
import Form from './component/form';
import Navbar from './component/Navbar';
function App() {
  return (<>
      <Navbar/>
      <Form />
    </>
    
    // <div className="App">
    //   <header className="App-header">
    //   </header>
    // </div>
  );
}

export default App;
